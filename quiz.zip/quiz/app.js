const quizzes = [
  { id: "clasicas", title: "Clásicas y legendarias" },
  { id: "futuristas", title: "Tecnología y futuro" },
  { id: "tematicas", title: "Temáticas y fantasía" }
];

const $ = (id) => document.getElementById(id);

let questions = [];
let current = 0;
let points = 0;
let selected = null;
let answered = false;
let hintUsed = false;

quizzes.forEach((quiz) => {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = quiz.title;
  button.addEventListener("click", () => startQuiz(quiz));
  $("quiz-buttons").append(button);
});

async function startQuiz(quiz) {
  try {
    const response = await fetch(`${quiz.id}.json`);

    if (!response.ok) {
      throw new Error(`No se pudo cargar ${quiz.id}.json.`);
    }

    const skins = await response.json();

    if (skins.length < 10) {
      throw new Error("El archivo del quiz debe contener al menos 10 skins.");
    }

    const availablePrices = [...new Set(skins.map((skin) => skin.price))];

    const questionBank = skins.map((skin) => {
      const wrongPrices = shuffle(
        availablePrices.filter((price) => price !== skin.price)
      ).slice(0, 3);

      const prices = shuffle([skin.price, ...wrongPrices]);

      return {
        question: `¿Cuánto cuesta la skin ${skin.name}?`,
        options: prices.map((price) => `${price} VP`),
        answer: prices.indexOf(skin.price),
        hint: `Pertenece al nivel ${skin.tier}.`
      };
    });

    questions = shuffle(questionBank).slice(0, 10);
    current = 0;
    points = 0;

    $("menu").classList.add("hidden");
    $("result").classList.add("hidden");
    $("game").classList.remove("hidden");

    showQuestion();
  } catch (error) {
    alert(`${error.message} Abre la página usando un servidor local.`);
  }
}

function showQuestion() {
  selected = null;
  answered = false;
  hintUsed = false;

  $("hint").textContent = "";
  $("progress").textContent = `Pregunta ${current + 1} de ${questions.length}`;
  $("score").textContent = `Puntos: ${points}`;
  $("progress-bar").style.width = `${(current / questions.length) * 100}%`;
  $("question").textContent = questions[current].question;
  $("confirm-button").textContent = "Confirmar";
  $("confirm-button").disabled = true;
  $("hint-button").disabled = false;

  const answersContainer = $("answers");
  answersContainer.replaceChildren();

  questions[current].options.forEach((option, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer";
    button.textContent = option;

    button.addEventListener("click", () => {
      if (answered) return;

      selected = index;

      document.querySelectorAll(".answer").forEach((answerButton) => {
        answerButton.classList.remove("selected");
      });

      button.classList.add("selected");
      $("confirm-button").disabled = false;
    });

    answersContainer.append(button);
  });
}

$("confirm-button").addEventListener("click", () => {
  if (!answered) {
    if (selected === null) return;

    answered = true;

    const question = questions[current];
    const answerButtons = [...document.querySelectorAll(".answer")];

    answerButtons[question.answer].classList.add("correct");

    if (selected === question.answer) {
      points++;
    } else {
      answerButtons[selected].classList.add("wrong");
    }

    $("score").textContent = `Puntos: ${points}`;
    $("confirm-button").textContent = "Siguiente pregunta";
    $("hint-button").disabled = true;
    return;
  }

  current++;

  if (current < questions.length) {
    showQuestion();
  } else {
    finishQuiz();
  }
});

$("hint-button").addEventListener("click", () => {
  if (hintUsed) return;

  hintUsed = true;
  $("hint").textContent = `Pista: ${questions[current].hint}`;
  $("hint-button").disabled = true;
});

function finishQuiz() {
  $("game").classList.add("hidden");
  $("result").classList.remove("hidden");

  $("final-score").textContent = `${points} / ${questions.length} puntos`;

  if (points === 10) {
    $("result-message").textContent = "¡Perfecto! Conoces los precios al detalle.";
  } else if (points >= 7) {
    $("result-message").textContent = "¡Buen trabajo, agente!";
  } else {
    $("result-message").textContent = "¡Sigue practicando para mejorar tu puntuación!";
  }

  saveScore();
}

$("back-button").addEventListener("click", () => {
  $("result").classList.add("hidden");
  $("menu").classList.remove("hidden");
  showRanking();
});

function shuffle(array) {
  const shuffled = [...array];

  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  return shuffled;
}

function saveScore() {
  const name = $("player-name").value.trim() || "Agente";
  const ranking = JSON.parse(localStorage.getItem("valorantRanking") || "[]");

  ranking.push({
    name,
    score: points,
    date: new Date().toLocaleDateString()
  });

  ranking.sort((a, b) => b.score - a.score);

  localStorage.setItem(
    "valorantRanking",
    JSON.stringify(ranking.slice(0, 10))
  );
}

function showRanking() {
  const ranking = JSON.parse(localStorage.getItem("valorantRanking") || "[]");
  const rankingList = $("ranking");

  rankingList.replaceChildren();

  ranking.forEach((entry) => {
    const item = document.createElement("li");
    item.textContent = `${entry.name} — ${entry.score}/10 (${entry.date})`;
    rankingList.append(item);
  });
}

showRanking();
